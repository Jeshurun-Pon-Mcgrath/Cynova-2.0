import { expect, test } from "@playwright/test";

const routes = ["/", "/login", "/register", "/forgot-password", "/onboarding", "/dashboard", "/quests", "/quests/new", "/quests/q1", "/character", "/skills", "/rewards", "/inventory", "/achievements", "/history", "/settings"];

test("every required route responds", async ({ request }) => {
  for (const route of routes) {
    const response = await request.get(route);
    expect(response.status(), route).toBe(200);
  }
});

test("dashboard fits a 360px phone and exposes mobile navigation", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", (error) => runtimeErrors.push(error.message));
  await page.setViewportSize({ width: 360, height: 800 });
  await page.goto("/dashboard");
  await expect(page.getByRole("heading", { name: /Good evening, Arin/i })).toBeVisible();
  await expect(page.getByRole("navigation", { name: "Mobile primary destinations" })).toBeVisible();
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);
  expect(runtimeErrors).toEqual([]);
});

test("landing hero is usable at desktop size", async ({ page }) => {
  const runtimeErrors: string[] = [];
  page.on("pageerror", (error) => runtimeErrors.push(error.message));
  await page.setViewportSize({ width: 1440, height: 900 });
  await page.goto("/");
  await expect(page.getByRole("heading", { name: /Your life\. Your quests\. Your legend\./i })).toBeVisible();
  await expect(page.getByRole("link", { name: "Enter Demo Realm" })).toBeVisible();
  expect(runtimeErrors).toEqual([]);
});
