import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  workers: 1,
  fullyParallel: false,
  reporter: "list",
  use: {
    baseURL: "http://127.0.0.1:3210",
    launchOptions: { executablePath: "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe" },
    trace: "retain-on-failure",
  },
  webServer: {
    command: "npm.cmd start -- -p 3210",
    url: "http://127.0.0.1:3210",
    reuseExistingServer: true,
    timeout: 30_000,
  },
});
