# CYNOVA — Life RPG

Cynova turns real-life work into quests that grow a fantasy character. This Phase 1 frontend delivers the judge-facing experience with typed seeded data, simulated service latency and failure, responsive layouts, accessible interaction patterns, GSAP feedback, and an optional procedural 3D Nova Core.

## Included experience

- Cinematic, crawlable landing page and procedural Three.js hero
- Login, registration, recovery, demo entry, and five-step onboarding
- Command centre with quests, XP, gold, streak, consistency, activity, and unlocks
- Searchable list/board quest archive, Zod/RHF creation, details, and deletion flows
- Character, keyboard-ready skills, rewards, inventory, achievements, chronicle, and preferences
- Loading, error, empty, missing-ID, offline, insufficient-gold, owned-item, WebGL fallback, and reduced-motion states

## Stack and architecture

Next.js App Router, strict TypeScript, React, Tailwind CSS plus centralized CSS tokens, Radix UI, Lucide, React Hook Form, Zod, Sonner, Zustand, TanStack Query, GSAP, React Three Fiber, Drei, Vitest, and Testing Library.

Pages are Server Components unless they own interactions. Async game data goes through contracts in `src/services/contracts` and development repositories in `src/services/mock`; TanStack Query owns caching and mutations. Zustand contains small UI preferences. Form state and validation stay in React Hook Form and Zod. Primary game data is never persisted to localStorage.

```text
frontend/
├─ public/
├─ src/
│  ├─ app/                 routes, layouts, metadata, errors
│  ├─ components/          layout, UI, motion, and Three.js
│  ├─ features/            domain-focused screens
│  ├─ data/                centralized seeded demo content
│  ├─ hooks/               reduced-motion behavior
│  ├─ lib/                 GSAP, query, validation, utilities
│  ├─ services/            typed contracts and mock repositories
│  ├─ stores/              ephemeral UI preferences
│  ├─ test/                deterministic test setup
│  └─ types/               domain model
├─ .env.example
└─ package.json
```

## Run locally

```bash
npm install
npm run dev
```

Verification:

```bash
npm run lint
npm run typecheck
npm run test
npm run build
```

On Windows systems where script execution blocks `npm.ps1`, use `npm.cmd` with the same arguments.

## Motion, accessibility, and performance

ScrollTrigger powers landing reveals, MotionPathPlugin flies completion energy toward the XP meter, and Flip is isolated in a reusable reorder group. GSAP contexts clean themselves up. `prefers-reduced-motion` removes particles, parallax, camera motion, and nonessential transitions; Settings can switch to low graphics, replacing WebGL with a semantic CSS core. The canvas is client-only, uses primitives, caps DPR, and never owns page controls.

Semantic landmarks, a skip link, AA-oriented contrast, visible focus, 44px controls, Radix focus-managed dialogs, status text, live toast feedback, chart text equivalents, responsive mobile navigation, safe-area spacing, and readable empty/error states are included.

## Mock behavior and Phase 2

Mock repositories simulate 250–600ms latency. The dashboard’s **Test rollback** control makes the next completion fail, proving the optimistic UI restores the quest and announces the error. In Phase 2, replace repository implementations with authenticated API adapters; keep query keys, forms, domain models, and UI unchanged. The backend becomes authoritative for auth, rewards, XP, inventory, anti-cheat rules, persistence, and synchronization.

## Deployment

Set the safe variables from `.env.example`, run `npm run build`, and import `frontend` into Vercel as the project root. No external 3D files or runtime media hosts are required.

## Assumptions

Phase 1 demo authentication intentionally grants direct entry and is not security. Sound is muted and no audio asset ships. Playwright is intentionally omitted to keep browser binaries from destabilizing a portable hackathon build; critical business behavior is covered by Vitest and Testing Library.
