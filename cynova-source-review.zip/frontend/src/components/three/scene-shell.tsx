"use client";
import dynamic from "next/dynamic";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { useUiStore } from "@/stores/ui-store";

const RealmCanvas = dynamic(() => import("./hero-realm-canvas"), { ssr: false, loading: () => <CoreFallback/> });
export function CoreFallback() { return <div className="canvas-fallback" role="img" aria-label="A glowing Nova Core representing Arin’s progress"><span className="orbit"/><span className="fallback-core"/></div>; }
export function SceneShell() { const reduced = useReducedMotion(); const graphics = useUiStore((s) => s.graphics); return reduced || graphics === "low" ? <CoreFallback/> : <RealmCanvas/>; }
