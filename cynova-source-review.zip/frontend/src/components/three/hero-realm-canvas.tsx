"use client";
import { Canvas } from "@react-three/fiber";
import { Suspense } from "react";
import { NovaCore } from "./nova-core";

export default function HeroRealmCanvas() {
  return <div className="canvas-shell" aria-hidden="true"><Canvas dpr={[1, 1.5]} camera={{ position: [0, .2, 6], fov: 42 }} gl={{ antialias: true, alpha: true }}>
    <ambientLight intensity={.7}/><pointLight position={[3,4,4]} intensity={28} color="#4DE8E0"/><pointLight position={[-4,-2,3]} intensity={18} color="#8B5CF6"/>
    <Suspense fallback={null}><NovaCore/></Suspense>
  </Canvas></div>;
}
