"use client";
import { Float, Icosahedron, Sparkles } from "@react-three/drei";
import { useFrame } from "@react-three/fiber";
import { useRef } from "react";
import type { Mesh } from "three";

export function NovaCore() {
  const core = useRef<Mesh>(null);
  useFrame((state, delta) => { if (core.current) { core.current.rotation.y += delta * .24; core.current.rotation.z = Math.sin(state.clock.elapsedTime * .5) * .08; } });
  return <Float speed={1.25} rotationIntensity={.18} floatIntensity={.6}>
    <group>
      <Icosahedron ref={core} args={[1.15, 1]}>
        <meshPhysicalMaterial color="#a8fffa" emissive="#4DE8E0" emissiveIntensity={1.4} roughness={.18} metalness={.15} transmission={.2}/>
      </Icosahedron>
      <mesh rotation-x={Math.PI / 2}><torusGeometry args={[1.65,.012,8,96]}/><meshBasicMaterial color="#4DE8E0" transparent opacity={.45}/></mesh>
      <mesh rotation={[Math.PI / 2.3, .3, .8]}><torusGeometry args={[1.9,.008,8,96]}/><meshBasicMaterial color="#8B5CF6" transparent opacity={.34}/></mesh>
      <Sparkles count={46} scale={5} size={2.3} speed={.25} color="#4DE8E0"/>
    </group>
  </Float>;
}
