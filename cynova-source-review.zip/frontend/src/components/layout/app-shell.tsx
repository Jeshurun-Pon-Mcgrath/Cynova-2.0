"use client";
import { Award, Backpack, BookOpenCheck, ChevronLeft, CircleUserRound, Coins, Flame, History, LayoutDashboard, Menu, Settings, ShoppingBag, Sparkles, X } from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { Logo } from "./logo";
import { useUiStore } from "@/stores/ui-store";

const nav = [
  ["Dashboard", "/dashboard", LayoutDashboard], ["Quests", "/quests", BookOpenCheck], ["Character", "/character", CircleUserRound], ["Skills", "/skills", Sparkles], ["Rewards", "/rewards", ShoppingBag], ["Inventory", "/inventory", Backpack], ["Achievements", "/achievements", Award], ["Chronicle", "/history", History], ["Settings", "/settings", Settings],
] as const;
export function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname(); const [open, setOpen] = useState(false); const { navCollapsed, toggleNav } = useUiStore();
  return <div className={`app-shell ${navCollapsed ? "rail" : ""}`}><a className="skip-link" href="#main">Skip to content</a><aside className={`sidebar ${open ? "open" : ""}`}><div className="sidebar-head"><Logo/><button className="icon-button desktop-only" onClick={toggleNav} aria-label={navCollapsed ? "Expand navigation" : "Collapse navigation"}><ChevronLeft/></button><button className="icon-button mobile-only" onClick={() => setOpen(false)} aria-label="Close navigation"><X/></button></div><nav aria-label="Game destinations">{nav.map(([label, href, Icon]) => <Link key={href} href={href} onClick={() => setOpen(false)} className={path.startsWith(href) ? "active" : ""} aria-current={path.startsWith(href) ? "page" : undefined}><Icon/><span>{label}</span></Link>)}</nav><div className="sidebar-quest"><span>Daily challenge</span><strong>3 / 5 quests</strong><div className="mini-bar"><i style={{ width: "60%" }}/></div></div></aside><div className="app-stage"><header className="top-hud"><button className="icon-button mobile-only" onClick={() => setOpen(true)} aria-label="Open navigation"><Menu/></button><div className="hud-spacer"/><span className="hud-pill"><Flame/>18 <span className="desktop-only">day streak</span></span><span className="hud-pill"><Coins/>1,260</span><Link href="/character" className="avatar" aria-label="Open Arin’s character">A</Link></header><main id="main" className="game-main">{children}</main></div>{open && <button className="sidebar-backdrop mobile-only" aria-label="Close navigation" onClick={() => setOpen(false)}/>}<nav className="bottom-nav" aria-label="Mobile primary destinations">{nav.slice(0,5).map(([label,href,Icon]) => <Link key={href} href={href} className={path.startsWith(href) ? "active" : ""}><Icon/><span>{label}</span></Link>)}</nav></div>;
}
