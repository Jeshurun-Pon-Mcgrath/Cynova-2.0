import type { Achievement, InventoryItem, Progression, Quest, Reward } from "@/types/domain";

export interface AuthService { signIn(email: string): Promise<{ name: string; email: string }>; enterDemo(): Promise<void> }
export interface QuestService { list(): Promise<Quest[]>; get(id: string): Promise<Quest | null>; create(input: Omit<Quest, "id" | "completionHistory" | "status">): Promise<Quest>; complete(id: string): Promise<{ quest: Quest; progression: Progression }> }
export interface ProgressionService { get(): Promise<Progression> }
export interface RewardService { list(): Promise<Reward[]>; purchase(id: string): Promise<Reward> }
export interface InventoryService { list(): Promise<InventoryItem[]>; equip(id: string): Promise<InventoryItem[]> }
export interface AchievementService { list(): Promise<Achievement[]> }
