import { achievements, progression, quests, rewards } from "@/data/seed";
import type { Achievement, InventoryItem, Progression, Quest, Reward } from "@/types/domain";

let questState = structuredClone(quests);
let progressionState = { ...progression };
let rewardState = structuredClone(rewards);
let failNextCompletion = false;
const wait = (ms = 320) => new Promise((resolve) => setTimeout(resolve, ms));

export function resetMockState() { questState = structuredClone(quests); progressionState = { ...progression }; rewardState = structuredClone(rewards); failNextCompletion = false; }
export function simulateNextCompletionFailure() { failNextCompletion = true; }
export const mockAuthService = {
  async signIn(email: string) { await wait(300); return { name: "Arin", email }; },
  async enterDemo() { await wait(250); },
};
export const mockQuestService = {
  async list() { await wait(); return structuredClone(questState); },
  async get(id: string) { await wait(260); return structuredClone(questState.find((q) => q.id === id) ?? null); },
  async create(input: Omit<Quest, "id" | "completionHistory" | "status">) { await wait(); const quest: Quest = { ...input, id: `q-${Date.now()}`, status: "active", completionHistory: [] }; questState = [quest, ...questState]; return structuredClone(quest); },
  async complete(id: string) {
    await wait(480);
    if (failNextCompletion) { failNextCompletion = false; throw new Error("The realm link flickered. Your quest was restored."); }
    const index = questState.findIndex((q) => q.id === id);
    if (index < 0) throw new Error("Quest not found");
    const source = questState[index];
    const completed: Quest = { ...source, status: "completed", completionHistory: [...source.completionHistory, { id: crypto.randomUUID(), questId: id, completedAt: new Date().toISOString(), xp: source.xpReward, gold: source.goldReward }] };
    questState[index] = completed;
    progressionState = { ...progressionState, currentXp: progressionState.currentXp + source.xpReward, gold: progressionState.gold + source.goldReward };
    if (progressionState.currentXp >= progressionState.nextLevelXp) progressionState = { ...progressionState, level: progressionState.level + 1, currentXp: progressionState.currentXp - progressionState.nextLevelXp, nextLevelXp: progressionState.nextLevelXp + 150 };
    return { quest: structuredClone(completed), progression: { ...progressionState } };
  },
};
export const mockProgressionService = { async get(): Promise<Progression> { await wait(280); return { ...progressionState }; } };
export const mockRewardService = {
  async list(): Promise<Reward[]> { await wait(); return structuredClone(rewardState); },
  async purchase(id: string): Promise<Reward> { await wait(420); const item = rewardState.find((r) => r.id === id); if (!item) throw new Error("Reward not found."); if (item.owned) throw new Error("This reward is already in your inventory."); if (item.cost > progressionState.gold) throw new Error("You need more gold for this reward."); progressionState.gold -= item.cost; item.owned = true; return structuredClone(item); },
};
export const mockInventoryService = {
  async list(): Promise<InventoryItem[]> { await wait(); return rewardState.filter((r) => r.owned).map((r) => ({ ...r, equipped: r.id === "r3" })); },
  async equip(id: string): Promise<InventoryItem[]> { await wait(260); return rewardState.filter((r) => r.owned).map((r) => ({ ...r, equipped: r.id === id })); },
};
export const mockAchievementService = { async list(): Promise<Achievement[]> { await wait(280); return structuredClone(achievements); } };
