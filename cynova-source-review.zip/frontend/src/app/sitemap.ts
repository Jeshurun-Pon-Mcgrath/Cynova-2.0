import type { MetadataRoute } from "next";
export default function sitemap():MetadataRoute.Sitemap{return["","/login","/register"].map(path=>({url:`https://cynova.life${path}`,lastModified:new Date(),changeFrequency:"weekly" as const,priority:path?0.7:1}))}
