"use client";
import { ArrowRight } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { Logo } from "@/components/layout/logo";
import { Button } from "@/components/ui/button";

type Mode = "login" | "register" | "forgot";
const copy = { login: ["Return to your realm", "Your quests and Nova Core are waiting."], register: ["Create your character", "Begin with a name. Build the legend one quest at a time."], forgot: ["Recover your realm", "We’ll send a secure recovery link if the account exists."] } as const;
export function AuthScreen({ mode }: { mode: Mode }) {
  const router = useRouter(); const [busy,setBusy]=useState(false); const [name,setName]=useState(""); const [email,setEmail]=useState(""); const [password,setPassword]=useState("");
  async function submit(event: FormEvent){event.preventDefault();setBusy(true);await new Promise((r)=>setTimeout(r,500));setBusy(false);if(mode==="forgot"){toast.success("Recovery instructions are on their way.");return} if(!email.includes("@")||password.length<8){toast.error("Enter a valid email and an 8-character password.");return} toast.success(mode==="login"?"Welcome back, adventurer.":"Your realm is ready to awaken.");router.push(mode==="register"?"/onboarding":"/dashboard")}
  return <main className="auth-page"><section className="auth-art" aria-label="Cynova welcome"><Logo/><p className="auth-quote">“Every legendary life is built from ordinary days used well.”</p><p className="muted">CYNOVA · LIFE RPG</p></section><section className="auth-form-wrap"><div className="auth-form"><Logo/><h1>{copy[mode][0]}</h1><p>{copy[mode][1]}</p><form onSubmit={submit} noValidate>{mode==="register"&&<div className="field"><label htmlFor="name">Player name</label><input id="name" autoComplete="name" value={name} onChange={(e)=>setName(e.target.value)} required minLength={2}/></div>}<div className="field"><label htmlFor="email">Email address</label><input id="email" type="email" autoComplete="email" value={email} onChange={(e)=>setEmail(e.target.value)} required placeholder="arin@example.com"/></div>{mode!=="forgot"&&<div className="field"><label htmlFor="password">Password</label><input id="password" type="password" autoComplete={mode==="login"?"current-password":"new-password"} value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={8}/><small>At least 8 characters.</small></div>}<Button disabled={busy} type="submit">{busy?"Opening portal…":mode==="login"?"Enter your realm":mode==="register"?"Create account":"Send recovery link"}<ArrowRight/></Button></form><div className="auth-links" style={{marginTop:20}}>{mode==="login"?<><Link href="/forgot-password">Forgot password?</Link><Link href="/register">Create account</Link></>:<Link href="/login">Return to login</Link>}<Link href="/dashboard">Enter demo realm</Link></div><p className="muted" style={{fontSize:12,marginTop:28}}>Demo authentication is for Phase 1 evaluation and is not production security.</p></div></section></main>;
}
