"use client";
import { useQuery } from "@tanstack/react-query";
import Link from "next/link";
import { mockQuestService } from "@/services/mock/game-service";
import { QuestDetail } from "./quest-detail";
export function QuestRoute({id}:{id:string}){const{data,isLoading,isError}=useQuery({queryKey:["quest",id],queryFn:()=>mockQuestService.get(id),retry:false});if(isLoading)return <div className="skeleton" aria-label="Loading quest"/>;if(isError||!data)return <div className="panel empty-state"><strong>That quest has faded from the archive.</strong><p>It may have been deleted or the link is incomplete.</p><Link className="button button-primary" href="/quests">Return to quests</Link></div>;return <QuestDetail quest={data}/>}
