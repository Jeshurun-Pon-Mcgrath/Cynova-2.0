import { render, screen } from "@testing-library/react";
import React from "react";
import userEvent from "@testing-library/user-event";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { vi, describe, expect, it } from "vitest";
import { QuestForm } from "./quest-form";
vi.mock("next/navigation",()=>({useRouter:()=>({push:vi.fn(),back:vi.fn()})}));
describe("QuestForm",()=>{it("shows title validation before submission",async()=>{const user=userEvent.setup();render(<QueryClientProvider client={new QueryClient()}><QuestForm/></QueryClientProvider>);await user.click(screen.getByRole("button",{name:"Create quest"}));expect(await screen.findByText("Quest title must be at least 3 characters.")).toBeInTheDocument()})})
