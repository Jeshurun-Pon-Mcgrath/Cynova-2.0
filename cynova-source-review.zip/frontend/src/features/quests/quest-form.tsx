"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Coins, Sparkles } from "lucide-react";
import { useRouter } from "next/navigation";
import { useMemo } from "react";
import { useForm, useWatch } from "react-hook-form";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { calculateReward } from "@/lib/utils";
import { questSchema, type QuestFormValues } from "@/lib/validation/quest";
import { mockQuestService } from "@/services/mock/game-service";

const attributes = ["Intellect", "Strength", "Vitality", "Charisma", "Creativity", "Discipline"];
const difficulties = ["Easy", "Standard", "Challenging", "Epic"];
const defaultDueAt = new Date(Date.now() + 86_400_000).toISOString().slice(0, 16);

export function QuestForm() {
  const router = useRouter();
  const client = useQueryClient();
  const { register, handleSubmit, control, formState: { errors } } = useForm<QuestFormValues>({
    resolver: zodResolver(questSchema),
    defaultValues: { title: "", description: "", category: "Intellect", difficulty: "Standard", estimatedMinutes: 30, recurrence: "None", dueAt: defaultDueAt },
  });
  const difficulty = useWatch({ control, name: "difficulty" });
  const minutes = useWatch({ control, name: "estimatedMinutes" });
  const reward = useMemo(() => calculateReward(difficulty, Number(minutes) || 5), [difficulty, minutes]);
  const create = useMutation({
    mutationFn: (values: QuestFormValues) => mockQuestService.create({ ...values, xpReward: reward.xp, goldReward: reward.gold, tags: [values.category.toLowerCase()] }),
    onSuccess: async () => { await client.invalidateQueries({ queryKey: ["quests"] }); toast.success(`Quest created · ${reward.xp} XP awaits`); router.push("/quests"); },
    onError: () => toast.error("The quest could not be inscribed. Try again."),
  });

  return <form className="panel form-panel" noValidate onSubmit={handleSubmit((values) => { if (!create.isPending) create.mutate(values); })}>
    <div className="form-grid">
      <div className="field full"><label htmlFor="title">Quest title</label><input id="title" placeholder="e.g. Finish the accessibility audit" {...register("title")} aria-invalid={!!errors.title}/>{errors.title && <span className="field-error" role="alert">{errors.title.message}</span>}</div>
      <div className="field full"><label htmlFor="description">Quest briefing <span className="muted">(optional)</span></label><textarea id="description" placeholder="Define what done looks like…" {...register("description")}/>{errors.description && <span className="field-error" role="alert">{errors.description.message}</span>}</div>
      <div className="field"><label htmlFor="category">Attribute path</label><select id="category" {...register("category")}>{attributes.map((value) => <option key={value}>{value}</option>)}</select></div>
      <div className="field"><label htmlFor="difficulty">Difficulty</label><select id="difficulty" {...register("difficulty")}>{difficulties.map((value) => <option key={value}>{value}</option>)}</select></div>
      <div className="field"><label htmlFor="dueAt">Due date and time</label><input id="dueAt" type="datetime-local" {...register("dueAt")} aria-invalid={!!errors.dueAt}/>{errors.dueAt && <span className="field-error" role="alert">{errors.dueAt.message}</span>}</div>
      <div className="field"><label htmlFor="minutes">Estimated duration</label><input id="minutes" type="number" min="5" max="480" {...register("estimatedMinutes", { valueAsNumber: true })}/>{errors.estimatedMinutes && <span className="field-error" role="alert">Choose 5–480 minutes.</span>}</div>
      <div className="field"><label htmlFor="recurrence">Recurrence</label><select id="recurrence" {...register("recurrence")}><option>None</option><option>Daily</option><option>Weekly</option></select></div>
      <div className="reward-preview"><Sparkles/><span><strong>+{reward.xp} XP</strong><br/><small>Preview</small></span><Coins/><span><strong>+{reward.gold} gold</strong><br/><small>Preview</small></span></div>
      <div className="reward-preview full"><small>Reward values are a Phase 1 preview based on duration and difficulty. The Phase 2 backend will be authoritative.</small></div>
    </div>
    <div className="form-actions"><Button type="button" variant="secondary" onClick={() => router.back()}>Cancel</Button><Button type="submit" disabled={create.isPending}>{create.isPending ? "Inscribing quest…" : "Create quest"}</Button></div>
  </form>;
}
