"use client";

import { useQuery } from "@tanstack/react-query";
import { Copy, LayoutGrid, List, Search } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { FlipGroup } from "@/components/motion/flip-group";
import { Button } from "@/components/ui/button";
import { QuestRow } from "@/features/dashboard/dashboard-view";
import { mockQuestService } from "@/services/mock/game-service";
import type { Attribute, Difficulty, QuestStatus } from "@/types/domain";

const attributes = ["Intellect", "Strength", "Vitality", "Charisma", "Creativity", "Discipline"];
const difficulties = ["Easy", "Standard", "Challenging", "Epic"];

export function QuestListView() {
  const { data = [], isLoading } = useQuery({ queryKey: ["quests"], queryFn: () => mockQuestService.list() });
  const [query, setQuery] = useState("");
  const [attribute, setAttribute] = useState<Attribute | "All">("All");
  const [difficulty, setDifficulty] = useState<Difficulty | "All">("All");
  const [view, setView] = useState<"list" | "board">("list");
  const filtered = useMemo(() => data.filter((quest) => quest.title.toLowerCase().includes(query.toLowerCase()) && (attribute === "All" || quest.category === attribute) && (difficulty === "All" || quest.difficulty === difficulty)), [data, query, attribute, difficulty]);
  const flipKey = `${query}-${attribute}-${difficulty}-${filtered.length}`;

  return <>
    <div className="page-head"><div><span className="eyebrow">Quest archive</span><h1>Choose your next move.</h1><p>Search, shape, and complete the actions that build your character.</p></div><Link href="/quests/new" className="button button-primary">Create quest</Link></div>
    <div className="toolbar">
      <label className="sr-only" htmlFor="quest-search">Search quests</label><div style={{ position: "relative", flex: 1 }}><Search style={{ position: "absolute", left: 13, top: 13, width: 18 }}/><input id="quest-search" style={{ width: "100%", paddingLeft: 42 }} placeholder="Search quests…" value={query} onChange={(event) => setQuery(event.target.value)}/></div>
      <label className="sr-only" htmlFor="attribute-filter">Attribute</label><select id="attribute-filter" value={attribute} onChange={(event) => setAttribute(event.target.value as Attribute | "All")}><option>All</option>{attributes.map((value) => <option key={value}>{value}</option>)}</select>
      <label className="sr-only" htmlFor="difficulty-filter">Difficulty</label><select id="difficulty-filter" value={difficulty} onChange={(event) => setDifficulty(event.target.value as Difficulty | "All")}><option>All</option>{difficulties.map((value) => <option key={value}>{value}</option>)}</select>
      <Button variant="secondary" size="icon" aria-label={view === "list" ? "Switch to board view" : "Switch to list view"} onClick={() => setView((value) => value === "list" ? "board" : "list")}>{view === "list" ? <LayoutGrid/> : <List/>}</Button>
    </div>
    {isLoading ? <div className="loading-grid"><div className="skeleton"/><div className="skeleton"/><div className="skeleton"/></div> : filtered.length === 0 ? <div className="panel empty-state"><Search/><strong>No quests found in this realm.</strong><p>Clear a filter or create a fresh quest.</p><Button variant="secondary" onClick={() => { setQuery(""); setAttribute("All"); setDifficulty("All"); }}>Clear filters</Button></div> : view === "list" ? <><p className="filter-results">{filtered.length} quests · sorted by due time</p><FlipGroup className="quest-grid" watch={flipKey}>{filtered.map((quest) => <div key={quest.id} className="panel"><QuestRow quest={quest} onComplete={() => toast.message("Complete quests from your dashboard to see the reward flight.")}/><div className="card-actions"><Link className="button button-ghost button-sm" href={`/quests/${quest.id}`}>Inspect</Link><Button variant="ghost" size="sm" onClick={() => toast.success(`Duplicated “${quest.title}” in this demo.`)}><Copy/>Duplicate</Button></div></div>)}</FlipGroup></> : <div className="quest-grid board">{(["active", "completed", "overdue"] as QuestStatus[]).map((status) => <section className="board-column" key={status}><h2>{status[0].toUpperCase() + status.slice(1)} · {filtered.filter((quest) => quest.status === status).length}</h2>{filtered.filter((quest) => quest.status === status).map((quest) => <QuestRow key={quest.id} quest={quest} onComplete={() => toast.message("Open dashboard to complete this quest.")}/>)}</section>)}</div>}
  </>;
}
