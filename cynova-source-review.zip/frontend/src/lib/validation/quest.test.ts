import { describe, expect, it } from "vitest";
import { questSchema } from "./quest";
describe("quest schema",()=>{it("rejects empty titles and invalid dates",()=>{const result=questSchema.safeParse({title:"",description:"",category:"Intellect",difficulty:"Easy",dueAt:"not-a-date",estimatedMinutes:30,recurrence:"None"});expect(result.success).toBe(false);if(!result.success){expect(result.error.flatten().fieldErrors.title).toBeDefined();expect(result.error.flatten().fieldErrors.dueAt).toBeDefined()}})})
