import { z } from "zod";

export const questSchema = z.object({
  title: z.string().trim().min(3, "Quest title must be at least 3 characters.").max(80),
  description: z.string().max(300).optional(),
  category: z.enum(["Intellect", "Strength", "Vitality", "Charisma", "Creativity", "Discipline"]),
  difficulty: z.enum(["Easy", "Standard", "Challenging", "Epic"]),
  dueAt: z.string().min(1, "Choose a due date.").refine((value) => !Number.isNaN(Date.parse(value)), "Enter a valid date."),
  estimatedMinutes: z.number().int().min(5).max(480),
  recurrence: z.enum(["None", "Daily", "Weekly"]),
});
export type QuestFormValues = z.infer<typeof questSchema>;
