"use client";
import gsap from "gsap";
import { ScrollTrigger, Flip, MotionPathPlugin } from "gsap/all";
if (typeof window !== "undefined") gsap.registerPlugin(ScrollTrigger, Flip, MotionPathPlugin);
export { gsap, ScrollTrigger, Flip, MotionPathPlugin };
