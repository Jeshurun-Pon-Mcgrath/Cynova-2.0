export type Attribute = "Intellect" | "Strength" | "Vitality" | "Charisma" | "Creativity" | "Discipline";
export type Archetype = "Scholar" | "Vanguard" | "Pathfinder" | "Alchemist";
export type Difficulty = "Easy" | "Standard" | "Challenging" | "Epic";
export type QuestStatus = "active" | "completed" | "overdue";

export interface User { id: string; email: string; name: string }
export interface PlayerProfile { userId: string; name: string; archetype: Archetype; level: number; attributes: Record<Attribute, number>; equipped: { frame: string; title: string; coreSkin: string } }
export interface Progression { currentXp: number; nextLevelXp: number; gold: number; level: number }
export interface Streak { days: number; protectedToday: boolean; best: number }
export interface QuestCompletion { id: string; questId: string; completedAt: string; xp: number; gold: number }
export interface Quest { id: string; title: string; description?: string; category: Attribute; difficulty: Difficulty; xpReward: number; goldReward: number; dueAt: string; recurrence: string; estimatedMinutes: number; status: QuestStatus; completionHistory: QuestCompletion[]; tags?: string[] }
export type RewardRarity = "Common" | "Rare" | "Epic" | "Legendary";
export interface Reward { id: string; name: string; description: string; category: "Themes" | "Core Skins" | "Avatar Frames" | "Titles" | "Streak Shields"; rarity: RewardRarity; cost: number; owned: boolean }
export interface InventoryItem extends Reward { equipped: boolean }
export interface Achievement { id: string; name: string; description: string; progress: number; target: number; unlockedAt?: string }
export interface ActivityEvent { id: string; text: string; at: string; kind: "quest" | "reward" | "level" | "achievement" }
export interface UserPreferences { reducedMotion: boolean; sound: boolean; graphics: "low" | "high"; theme: "dark" | "contrast" }
