import { create } from "zustand";

interface UiState { navCollapsed: boolean; graphics: "low" | "high"; sound: boolean; toggleNav: () => void; setGraphics: (value: "low" | "high") => void; setSound: (value: boolean) => void }
export const useUiStore = create<UiState>((set) => ({ navCollapsed: false, graphics: "high", sound: false, toggleNav: () => set((state) => ({ navCollapsed: !state.navCollapsed })), setGraphics: (graphics) => set({ graphics }), setSound: (sound) => set({ sound }) }));
