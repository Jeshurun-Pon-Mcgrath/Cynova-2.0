import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(import.meta.dirname, "./src") } },
  test: { environment: "jsdom", setupFiles: ["./src/test/setup.ts"], globals: true, exclude: ["e2e/**", "node_modules/**", ".next/**"] },
});
